# cs465-fullstack
CS-465 Full Stack Development with MEAN

# 🌴 Travlr Getaways – Full Stack Travel Booking Platform

Welcome to Travlr Getaways — a full stack travel booking application built from scratch using the MEAN stack: **MongoDB, Express.js, Angular, and Node.js**. This platform lets customers explore amazing travel packages while giving administrators the tools they need to manage those experiences from behind the scenes.

## 🧠 Architecture

This project pushed me deep into understanding how different frontend approaches work. On the public-facing site, I used **Express with Handlebars templates** to render pages dynamically with HTML and server-side logic. It feels familiar, efficient, and direct — great for delivering content to customers.

On the other hand, the admin panel was built as a **single-page application (SPA)** using standalone **Angular components**. That meant ditching the usual `.component.ts` and `.service.ts` patterns and doing everything with `standalone: true` setups. Most examples and documentation didn’t match what I was building, so I had to troubleshoot from the ground up, tying each piece together manually. That challenge made me slow down and really absorb how the modules connect, how routing flows, and how services talk to each other.

Why NoSQL? MongoDB gave us a flexible schema structure to match our dynamic data needs — travel packages vary a lot in content, and we needed a database that could store and retrieve them without enforcing strict rules on every single field. Using **Mongoose ODM** with our Express backend gave me the structure I needed without losing the freedom NoSQL offers.

## ⚙️ Functionality

At the heart of this application is **JSON** — it's the glue that connects our frontend and backend. JSON (JavaScript Object Notation) is not JavaScript itself, but it *is* the bridge between them. Angular apps make HTTP requests and receive JSON from the Node/Express API, which pulls that data from MongoDB. Clean, predictable, and easily parsed — JSON keeps the data flowing smoothly.

I also spent a lot of time **refactoring** components in Angular. The original examples used different structures, so I rewired everything into a reactive form approach. By building **reusable components**, like form controls for adding and editing trips, I was able to improve the efficiency of the UI and reduce redundancy. That not only sped up development, it made the whole experience cleaner for future maintenance.

## 🧪 Testing

API endpoints don’t test themselves — especially when security is layered in. I validated **GET**, **POST**, and **PUT** requests throughout the project. JWT authentication added complexity, but it was a worthwhile challenge. I made sure that:

- Users can log in securely with tokens.
- Admin pages are protected behind authenticated routes.
- The app only allows valid requests with correct headers and token checks.

Understanding how Angular’s `HttpClient` works with interceptors helped me enforce authorization rules and handle response errors — and those trials taught me how to test APIs in a realistic, secure environment.

## 🌟 Reflection

This project has been a fun but challenging point in my journey as a developer. It helped me master how **each piece of a full stack app fits together** — from routing and data binding to backend models and token-based security. I didn’t just build a working app. I built an understanding that I cannot wait to try on something else!

I’ve sharpened skills in Angular, API development, MongoDB schema design, and frontend/backend integration. Just as importantly, I’ve learned how to **adapt and debug** when working outside of pre-built templates — and that’s something that will serve me in any real-world development setting.

Travlr Getaways isn’t just a travel booking platform — it’s the result of persistence, learning through iteration, and building confidence by solving problems one step at a time. Thanks for checking it out!

---

🧭 **Built With:**
- Angular (SPA Admin Panel)
- Express.js (Customer Site)
- MongoDB + Mongoose
- Node.js
- JSON Web Tokens (JWT)
