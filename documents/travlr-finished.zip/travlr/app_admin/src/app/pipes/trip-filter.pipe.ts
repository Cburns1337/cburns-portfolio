import { Pipe, PipeTransform } from '@angular/core';
import { Trip } from '../models/trip';

@Pipe({
  name: 'tripFilter',
  standalone: true
})
export class TripFilterPipe implements PipeTransform {
  transform(trips: Trip[], searchTerm: string): Trip[] {
    if (!trips || !searchTerm) return trips;

    const lowerSearch = searchTerm.toLowerCase();
    return trips.filter(trip =>
      trip.name.toLowerCase().includes(lowerSearch) ||
      trip.resort.toLowerCase().includes(lowerSearch)
    );
  }
}
