import { Routes } from '@angular/router';
import { AddTrip } from './add-trip/add-trip';
import { TripListing } from './trip-listing/trip-listing';
import { EditTrip } from './edit-trip/edit-trip';
import { LoginComponent } from './login/login';
import { authGuard } from './auth-guard'; // functional guard

export const routes: Routes = [
  // Admin-only (protected)
  { path: 'add-trip',  component: AddTrip,  canActivate: [authGuard], title: 'Add Trip' },
  { path: 'edit-trip', component: EditTrip, canActivate: [authGuard], title: 'Edit Trip' },

  // Public
  { path: 'login', component: LoginComponent, title: 'Admin Login' },
  { path: '', component: TripListing, pathMatch: 'full', title: 'Trips' },

  // Fallback
  { path: '**', redirectTo: '' }
];
