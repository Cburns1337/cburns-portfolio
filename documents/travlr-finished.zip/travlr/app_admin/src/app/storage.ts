import { InjectionToken } from '@angular/core';

/**
 * Browser storage injection token.
 * Uses real DOM Storage when available, with a safe no-op fallback (SSR/tests).
 */
export const BROWSER_STORAGE = new InjectionToken<globalThis.Storage>(
  'Browser Storage',
  {
    providedIn: 'root',
    factory: () =>
      (typeof window !== 'undefined' && window.localStorage)
        ? window.localStorage
        : {
            getItem: (_: string) => null,
            setItem: (_k: string, _v: string) => {},
            removeItem: (_: string) => {},
            clear: () => {},
            key: (_: number) => null,
            length: 0
          } as globalThis.Storage
  }
);

