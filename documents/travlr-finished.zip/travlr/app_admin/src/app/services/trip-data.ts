import { Injectable, Inject } from '@angular/core';
import { HttpClient, HttpParams } from '@angular/common/http';
import { Observable, throwError } from 'rxjs';
import { catchError, tap } from 'rxjs/operators';

import { Trip } from '../models/trip';
import { User } from '../models/user';
import { AuthResponse } from '../models/auth-response';
import { BROWSER_STORAGE } from '../storage';

@Injectable({ providedIn: 'root' })
export class TripData {
  /**
   * Prefer a relative /api for same-origin dev.
   * For production, you can inject a runtime value via window.__API__ in index.html.
   */
  private baseUrl: string = (window as any).__API__ ?? '/api';

  private TOKEN_KEY = 'travlr-token';

  constructor(
    private http: HttpClient,
    @Inject(BROWSER_STORAGE) private storage: Storage
  ) {}

  /** Public helper to read the current JWT if needed elsewhere */
  get token(): string | null {
    return this.storage.getItem(this.TOKEN_KEY);
  }

  /** Remove token and (optionally) let the router/interceptor redirect */
  logout(): void {
    this.storage.removeItem(this.TOKEN_KEY);
  }

  // ---------------- Trips ----------------

  /** Fetch all trips, optionally filtered by searchTerm */
  getTrips(searchTerm: string = ''): Observable<Trip[]> {
    const q = (searchTerm || '').trim();
    let params = new HttpParams();
    if (q.length >= 1) params = params.set('search', q);
    return this.http
      .get<Trip[]>(`${this.baseUrl}/trips`, { params })
      .pipe(catchError(this.handleError<Trip[]>('getTrips')));
  }

  /** Add a new trip (requires JWT via interceptor) */
  addTrip(formData: Trip): Observable<Trip> {
    return this.http
      .post<Trip>(`${this.baseUrl}/trips`, formData)
      .pipe(catchError(this.handleError<Trip>('addTrip')));
  }

  /** Retrieve a trip by code */
  getTripByCode(tripCode: string): Observable<Trip> {
    const code = encodeURIComponent(tripCode);
    return this.http
      .get<Trip>(`${this.baseUrl}/trips/${code}`)
      .pipe(catchError(this.handleError<Trip>('getTripByCode')));
  }

  /** Update an existing trip by code (requires JWT via interceptor) */
  updateTripByCode(code: string, formData: Trip): Observable<Trip> {
    const safe = encodeURIComponent(code);
    return this.http
      .put<Trip>(`${this.baseUrl}/trips/${safe}`, formData)
      .pipe(catchError(this.handleError<Trip>('updateTripByCode')));
  }

  // ---------------- Auth ----------------

  /** Login endpoint: stores JWT on success */
  login(user: User, passwd: string): Observable<AuthResponse> {
    return this.handleAuthAPICall('login', user, passwd);
  }

  /** Register endpoint: stores JWT on success */
  register(user: User, passwd: string): Observable<AuthResponse> {
    return this.handleAuthAPICall('register', user, passwd);
  }

  /** Shared logic for login/register */
  private handleAuthAPICall(
    endpoint: 'login' | 'register',
    user: User,
    passwd: string
  ): Observable<AuthResponse> {
    const body = { name: user.name, email: user.email, password: passwd };
    return this.http
      .post<AuthResponse>(`${this.baseUrl}/${endpoint}`, body)
      .pipe(
        tap((res) => {
          if (res && (res as any).token) {
            this.storage.setItem(this.TOKEN_KEY, (res as any).token);
          }
        }),
        catchError(this.handleError<AuthResponse>(endpoint))
      );
  }

  // ---------------- Errors ----------------

  private handleError<T>(op = 'operation') {
    return (err: any) => {
      // You can enhance this to use a toaster service, etc.
      console.error(`[TripData] ${op} failed:`, err);
      return throwError(() => err);
    };
  }
}
