import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { Trip } from '../models/trip';
import { TripData } from '../services/trip-data';
import { TripCard } from '../trip-card/trip-card';
import { Router } from '@angular/router';
import { AuthenticationService } from '../services/authentication';
import { FormsModule } from '@angular/forms';

@Component({
  selector: 'app-trip-listing',
  standalone: true,
  imports: [CommonModule, TripCard, FormsModule],
  templateUrl: './trip-listing.html',
  styleUrls: ['./trip-listing.css']
})
export class TripListing implements OnInit {
  public trips: Trip[] = [];
  public filteredTrips: Trip[] = [];
  public message = '';
  public loading = true;

  public searchResort = '';
  public sortOption: 'price' | 'duration' | '' = '';

  constructor(
    private tripDataService: TripData,
    private router: Router,
    private authenticationService: AuthenticationService
  ) {}

  ngOnInit(): void {
    this.loadTrips();
  }

  public isLoggedIn(): boolean {
    return this.authenticationService.isLoggedIn();
  }

  public addTrip(): void {
    this.router.navigate(['add-trip']);
  }

  private loadTrips(): void {
    this.loading = true;
    this.tripDataService.getTrips().subscribe({
      next: (trips: Trip[]) => {
        this.trips = trips;
        this.applyFilters();
        this.message = trips.length > 0
          ? `There are ${trips.length} trips available.`
          : 'There were no trips retrieved from the database';
        this.loading = false;
      },
      error: (error: any) => {
        console.error('Error loading trips:', error);
        this.message = 'An error occurred while loading trips. Please try again later.';
        this.loading = false;
      }
    });
  }

  public applyFilters(): void {
    this.filteredTrips = this.trips.filter(trip =>
      trip.resort.toLowerCase().includes(this.searchResort.toLowerCase())
    );

    if (this.sortOption === 'price') {
      this.filteredTrips.sort((a, b) => Number(a.perPerson) - Number(b.perPerson));
    } else if (this.sortOption === 'duration') {
      this.filteredTrips.sort((a, b) => Number(a.length) - Number(b.length));
    }
  }

  public onSearchChange(): void {
    this.applyFilters();
  }

  public onSortChange(option: string): void {
    this.sortOption = option as 'price' | 'duration' | '';
    this.applyFilters();
  }
}
