import { inject } from '@angular/core';
import { CanActivateFn, Router, UrlTree } from '@angular/router';
import { BROWSER_STORAGE } from './storage';

const TOKEN_KEY = 'travlr-token';

function isTokenValid(token: string): boolean {
  try {
    // Basic JWT payload decode (no signature verify, just checks exp)
    const payload = JSON.parse(atob(token.split('.')[1] || ''));
    if (!payload || typeof payload.exp !== 'number') return false;
    const now = Math.floor(Date.now() / 1000);
    return payload.exp > now; // not expired
  } catch {
    return false;
  }
}

export const authGuard: CanActivateFn = (route, state): boolean | UrlTree => {
  const storage = inject(BROWSER_STORAGE);
  const router = inject(Router);

  const token = storage.getItem(TOKEN_KEY);
  const ok = token && isTokenValid(token);

  if (ok) return true;

  // Clear any bad/expired token and bounce to login
  storage.removeItem(TOKEN_KEY);
  return router.createUrlTree(['/login'], { queryParams: { returnUrl: state.url } });
};
