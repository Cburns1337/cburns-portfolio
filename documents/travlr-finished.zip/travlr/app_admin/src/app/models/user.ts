export class User {
  email: string;
  name: string;

  constructor() {
    this.email = '';
    this.name = '';
  }
}