import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormBuilder, FormGroup, Validators, ReactiveFormsModule } from '@angular/forms';
import { ActivatedRoute, Router } from '@angular/router';
import { TripData } from '../services/trip-data';
import { Trip } from '../models/trip';

@Component({
  selector: 'app-edit-trip',
  standalone: true,
  imports: [CommonModule, ReactiveFormsModule],
  templateUrl: './edit-trip.html',
  styleUrls: ['./edit-trip.css']
})
export class EditTrip implements OnInit {
  editForm!: FormGroup;
  submitted = false;
  tripCode: string = '';
  trip!: Trip;
  message: string = '';

  constructor(
    private fb: FormBuilder,
    private route: ActivatedRoute,
    private router: Router,
    private tripService: TripData
  ) {}

  ngOnInit(): void {
    // Initialize form
    this.editForm = this.fb.group({
      _id: [''],
      code: ['', Validators.required],
      name: ['', Validators.required],
      length: ['', Validators.required],
      start: ['', Validators.required],
      resort: ['', Validators.required],
      perPerson: ['', Validators.required],
      image: ['', Validators.required],
      description: ['', Validators.required]
    });

    // Get trip code from route or localStorage
    this.tripCode = this.route.snapshot.paramMap.get('tripCode') || localStorage.getItem('tripCode') || '';
    if (!this.tripCode) {
      alert("No trip code found.");
      this.router.navigate(['']);
      return;
    }

    // Fetch trip data and populate the form
    this.tripService.getTripByCode(this.tripCode).subscribe({
      next: (trip: any) => {
        const actualTrip = Array.isArray(trip) ? trip[0] : trip;

        // Format date to YYYY-MM-DD for date input compatibility
        if (actualTrip.start) {
          actualTrip.start = new Date(actualTrip.start).toISOString().split('T')[0];
        }

        this.trip = actualTrip;
        this.editForm.patchValue(actualTrip);
        this.message = `Trip ${actualTrip.code} loaded.`;
        console.log(this.message);
      },
      error: (err: any) => {
        console.error('Error fetching trip:', err);
        this.router.navigate(['/']);
      }
    });
  }

  get f() {
    return this.editForm.controls;
  }

  onSubmit(): void {
    this.submitted = true;

    if (this.editForm.invalid) return;

    // Trim inputs and format date properly
    const cleanedTrip: Trip = {
      ...this.editForm.value,
      code: this.editForm.value.code?.trim(),
      name: this.editForm.value.name?.trim(),
      length: this.editForm.value.length?.trim(),
      start: new Date(this.editForm.value.start).toISOString(),
      resort: this.editForm.value.resort?.trim(),
      perPerson: this.editForm.value.perPerson?.trim(),
      image: this.editForm.value.image?.trim(),
      description: this.editForm.value.description?.trim()
    };

    // Send update request
    this.tripService.updateTripByCode(this.tripCode, cleanedTrip).subscribe({
      next: () => {
        console.log('Trip updated successfully.');
        this.router.navigate(['/']);
      },
      error: (error) => {
        console.error('Update error:', error);
        this.message = 'Trip update failed.';
      }
    });
  }
}
