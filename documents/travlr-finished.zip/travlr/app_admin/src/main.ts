import { bootstrapApplication } from '@angular/platform-browser';
import { App } from './app/app';
import { appConfig } from './app/app.config';
import { authInterceptProvider } from './app/utils/jwt-interceptor';

bootstrapApplication(App, {
  ...appConfig,
  providers: [
    ...(appConfig.providers ?? []),
    authInterceptProvider 
  ]
}).catch((err) => console.error(err));