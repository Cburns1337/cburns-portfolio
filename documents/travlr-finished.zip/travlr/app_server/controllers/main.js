/* GET Homepage */
const index = (req, res) => {
    res.render('index', { title: 'Travlr Getaaways'});
};

module.exports = {
    index
}
