var express = require('express');
var router = express.Router();
const crtlMain = require('../controllers/main');

/* GET home page. */
router.get('/', (req, res) => {
    res.render('index', { title: 'Travlr Home' });      
});

module.exports = router;
