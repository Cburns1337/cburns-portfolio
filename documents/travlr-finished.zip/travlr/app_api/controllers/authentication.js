const passport = require('passport');
const validator = require('validator');
const User = require('../models/user');

/** Centralized, sanitized error sender */
const sendError = (res, status = 500, message = 'Server error', err) => {
  if (process.env.NODE_ENV !== 'production' && err) {
    // Log full detail in non-prod
    // eslint-disable-next-line no-console
    console.error('[auth]', message, err);
  }
  return res.status(status).json({ message });
};

/** Normalize & validate email safely */
const normalizeEmail = (email) => {
  const e = typeof email === 'string' ? email.trim() : '';
  const normalized = validator.normalizeEmail(e, {
    gmail_remove_dots: false,
    gmail_remove_subaddress: true,
    gmail_convert_googlemaildotcom: true
  });
  return normalized || '';
};

/** Clamp and sanitize a display name */
const cleanName = (name) => {
  const n = typeof name === 'string' ? name.trim() : '';
  const escaped = validator.escape(validator.stripLow(n, true));
  return escaped.slice(0, 50);
};

/** Ensure password policy */
const isStrong = (pwd) =>
  typeof pwd === 'string' &&
  validator.isStrongPassword(pwd, {
    minLength: 8,
    minLowercase: 1,
    minUppercase: 1,
    minNumbers: 1,
    minSymbols: 1,
  });

/** Shape the safe user payload returned to clients */
const shapeUser = (u) => ({ _id: u._id, email: u.email, name: u.name });

/** POST /register */
const register = async (req, res) => {
  try {
    const name = cleanName(req.body?.name);
    const email = normalizeEmail(req.body?.email);
    const password = req.body?.password ?? '';

    if (!name || !email || !password) {
      return res.status(400).json({ message: 'All fields are required' });
    }
    if (!validator.isEmail(email)) {
      return res.status(400).json({ message: 'Invalid email format' });
    }
    if (!isStrong(password)) {
      return res.status(400).json({
        message:
          'Password must be at least 8 characters and include upper/lowercase, a number, and a symbol',
      });
    }

    // Prevent duplicate account creation
    const exists = await User.exists({ email }).lean();
    if (exists) {
      return res.status(409).json({ message: 'Email already in use' });
    }

    const user = new User({ name, email });
    await user.setPassword(password);
    await user.save();

    const token = user.generateJWT(); // uses JWT_SECRET & JWT_EXPIRES_IN
    return res
      .status(201)
      .json({ token, user: shapeUser(user), message: 'Registration successful' });
  } catch (err) {
    return sendError(res, 500, 'Registration failed', err);
  }
};

/** POST /login */
const login = (req, res) => {
  try {
    const email = normalizeEmail(req.body?.email);
    const password = req.body?.password ?? '';

    if (!email || !password) {
      return res.status(400).json({ message: 'All fields are required' });
    }

    // Use Passport local strategy; no sessions in JWT flows
    passport.authenticate(
      'local',
      { session: false },
      (err, user /*, info */) => {
        if (err) return sendError(res, 500, 'Login error', err);
        if (!user) {
          // Do not reveal whether email exists
          return res.status(401).json({ message: 'Invalid email or password' });
        }
        const token = user.generateJWT();
        return res
          .status(200)
          .json({ token, user: shapeUser(user), message: 'Login successful' });
      }
    )(req, res);
  } catch (err) {
    return sendError(res, 500, 'Unexpected login error', err);
  }
};

module.exports = { register, login };
