const mongoose = require('mongoose');
const Trip = require('../models/travlr');
const Model = mongoose.model('Trip');
const validator = require('validator');

// Reusable error handler
const handleError = (res, err, message = 'Internal Server Error', status = 500) => {
  console.error(message, err);
  return res.status(status).json({ error: message });
};

// GET: /trips - lists all the trips (with optional filtering)
const tripsList = async (req, res) => {
  try {
    const { search } = req.query;
    let query = {};

    if (search) {
      const regex = new RegExp(search, 'i');
      query = {
        $or: [
          { code: regex },
          { name: regex },
          { description: regex },
          { resort: regex }
        ]
      };
    }

    const trips = await Model.find(query).exec();
    if (!trips || trips.length === 0) {
      return res.status(404).json({ message: 'No trips found' });
    }
    return res.status(200).json(trips);
  } catch (err) {
    return handleError(res, err, 'Error fetching trip list');
  }
};

// GET: /trips/:tripCode - lists a single trip
const tripsFindByCode = async (req, res) => {
  try {
    const code = req.params.tripCode?.trim();
    if (!code) return res.status(400).json({ message: 'Trip code is required' });

    const trip = await Model.findOne({ code }).exec();
    if (!trip) {
      return res.status(404).json({ message: 'Trip not found' });
    }
    return res.status(200).json(trip);
  } catch (err) {
    return handleError(res, err, 'Error fetching trip');
  }
};

// POST: /trips - Adds a new trip
const tripsAddTrip = async (req, res) => {
  try {
    const {
      code, name, length, start,
      resort, perPerson, image, description
    } = req.body;

    if (!code || !name || !start) {
      return res.status(400).json({ message: 'Code, Name, and Start date are required' });
    }

    const newTrip = new Trip({
      code: validator.escape(code.trim()),
      name: validator.escape(name.trim()),
      length: validator.escape(length?.toString() || ''),
      start: new Date(start),
      resort: validator.escape(resort?.trim() || ''),
      perPerson: validator.escape(perPerson?.toString() || ''),
      image: validator.escape(image?.trim() || ''),
      description: validator.escape(description?.trim() || '')
    });

    const saved = await newTrip.save();
    return res.status(201).json(saved);
  } catch (err) {
    return handleError(res, err, 'Error adding trip');
  }
};

// PUT: /trips/:tripCode - Updates an existing trip
const tripsUpdateTrip = async (req, res) => {
  try {
    const code = req.params.tripCode?.trim();
    if (!code) return res.status(400).json({ message: 'Trip code is required' });

    const trip = await Model.findOne({ code }).exec();
    if (!trip) {
      return res.status(404).json({ message: 'Trip not found' });
    }

    const fields = ['code', 'name', 'length', 'start', 'resort', 'perPerson', 'image', 'description'];
    fields.forEach(field => {
      if (req.body[field]) {
        if (field === 'start') {
          const dateVal = new Date(req.body[field]);
          if (!isNaN(dateVal)) trip[field] = dateVal;
        } else {
          trip[field] = validator.escape(req.body[field].toString().trim());
        }
      }
    });

    const updatedTrip = await trip.save();
    return res.status(200).json(updatedTrip);
  } catch (err) {
    return handleError(res, err, 'Error updating trip');
  }
};

module.exports = {
  tripsList,
  tripsFindByCode,
  tripsAddTrip,
  tripsUpdateTrip
};
