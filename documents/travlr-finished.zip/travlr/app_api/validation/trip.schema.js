// app_api/validation/trip.schema.js
const { z } = require('zod');

const codeSchema = z
  .string()
  .min(2)
  .max(20)
  .trim()
  .transform((v) => v.toUpperCase())
  .refine((v) => /^[A-Z0-9-]+$/.test(v), {
    message: 'Code must be alphanumeric (A–Z, 0–9) and dashes only'
  });

const startSchema = z
  .string()
  .trim()
  .refine((v) => !isNaN(Date.parse(v)), {
    message: 'start must be an ISO-8601 date string'
  });

const imageUrlSchema = z
  .string()
  .url()
  .refine((v) => v.startsWith('http://') || v.startsWith('https://'), {
    message: 'Image URL must start with http:// or https://'
  });

const tripSchema = z.object({
  code: codeSchema,
  name: z.string().min(2).max(80).trim(),
  length: z.coerce.number().int().positive().max(365),
  start: startSchema, // router middleware will coerce to Date
  resort: z.string().min(2).max(80).trim(),
  perPerson: z.coerce.number().nonnegative().max(1_000_000),
  image: z.union([z.literal(''), imageUrlSchema]).optional(),
  description: z.string().min(10).max(2000).trim()
});

const querySchema = z.object({
  search: z.string().trim().max(80).optional()
});

module.exports = { tripSchema, querySchema };
