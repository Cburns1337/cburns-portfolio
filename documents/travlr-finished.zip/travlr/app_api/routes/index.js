const express = require('express');
const router = express.Router();
const passport = require('passport');

// Controllers
const tripsController = require('../controllers/trips');
const authController = require('../controllers/authentication');

// Validation
const { validate } = require('../middleware/validate');
const { tripSchema, querySchema } = require('../validation/trip.schema');

// Require a valid JWT for protected routes (no sessions in JWT flows)
const requireJwt = passport.authenticate('jwt', { session: false });

/**
 * Coerce body.start (ISO string) -> Date, if valid.
 * Your Trip model expects a Date; the validator accepts a string.
 */
const coerceStartDate = (req, _res, next) => {
  if (req.body && typeof req.body.start === 'string') {
    const d = new Date(req.body.start);
    if (!isNaN(d.getTime())) req.body.start = d;
  }
  next();
};

// ---- Auth ----
router.post('/login', authController.login);
router.post('/register', authController.register);

// ---- Trips (public reads) ----
router.get('/trips', validate(querySchema, 'query'), tripsController.tripsList);
router.get('/trips/:tripCode', tripsController.tripsFindByCode);

// ---- Trips (protected writes) ----
router.post('/trips', requireJwt, validate(tripSchema), coerceStartDate, tripsController.tripsAddTrip);
router.put('/trips/:tripCode', requireJwt, validate(tripSchema), coerceStartDate, tripsController.tripsUpdateTrip);

// ---- Test ----
router.get('/test', (_req, res) => res.status(200).json({ message: 'API is working' }));

module.exports = router;
