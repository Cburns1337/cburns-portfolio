// app_api/config/passport.js
const passport = require('passport');
const LocalStrategy = require('passport-local').Strategy;
const { Strategy: JwtStrategy, ExtractJwt } = require('passport-jwt');
const validator = require('validator');
const User = require('../models/user');

const normalizeEmail = (email) =>
  (validator.normalizeEmail((email || '').trim(), {
    gmail_remove_dots: false,
    gmail_remove_subaddress: true,
    gmail_convert_googlemaildotcom: true
  }) || '').toLowerCase();

/* ----- Local: email + password (no sessions) ----- */
passport.use(new LocalStrategy(
  { usernameField: 'email', passwordField: 'password', session: false },
  async (email, password, done) => {
    try {
      // Early reject if missing fields (controller also checks)
      if (!email || !password) return done(null, false);

      const normalized = normalizeEmail(email);
      const user = await User.findOne({ email: normalized })
        .select('+passwordHash')
        .exec();
      if (!user) return done(null, false);

      const ok = await user.validPassword(password);
      return ok ? done(null, user) : done(null, false);
    } catch (err) {
      return done(err);
    }
  }
));

/* ----- JWT: Authorization: Bearer <token> ----- */
if (!process.env.JWT_SECRET) {
  // eslint-disable-next-line no-console
  console.warn('[passport] JWT_SECRET is not set; JWT auth will fail.');
}

const jwtOpts = {
  jwtFromRequest: ExtractJwt.fromAuthHeaderAsBearerToken(),
  secretOrKey: process.env.JWT_SECRET,
  algorithms: ['HS256'],
  ignoreExpiration: false,
  clockTolerance: 5, // seconds; helps with small clock drift
  // Optional extra checks if you set these in your environment:
  ...(process.env.JWT_ISSUER ? { issuer: process.env.JWT_ISSUER } : {}),
  ...(process.env.JWT_AUDIENCE ? { audience: process.env.JWT_AUDIENCE } : {})
};

passport.use(new JwtStrategy(jwtOpts, async (payload, done) => {
  try {
    // We set sub = user id in user.generateJWT()
    const user = await User.findById(payload.sub).exec();
    return user ? done(null, user) : done(null, false);
  } catch (err) {
    return done(err, false);
  }
}));

module.exports = passport;
