// app_api/middleware/validate.js
const { ZodError } = require('zod');

const pickSource = (req, source) => {
  switch (source) {
    case 'query':  return req.query  ?? {};
    case 'params': return req.params ?? {};
    case 'body':
    default:       return req.body   ?? {};
  }
};

const validate = (schema, source = 'body') => (req, res, next) => {
  const input = pickSource(req, source);
  const parsed = schema.safeParse(input);

  if (!parsed.success) {
    const errors = parsed.error.issues.map(i => ({
      path: i.path.join('.'),
      message: i.message,
      code: i.code
    }));
    return res.status(400).json({ message: 'Validation error', errors });
  }

  // Overwrite with the cleaned/stripped data from Zod
  req[source] = parsed.data;
  return next();
};

module.exports = { validate };
