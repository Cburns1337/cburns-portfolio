const mongoose = require('mongoose');

// ----- Config & safe defaults -----
const DB_NAME = process.env.DB_NAME || 'travlr';
const DB_HOST = process.env.DB_HOST || '127.0.0.1';
const DB_URI =
  process.env.MONGODB_URI || `mongodb://${DB_HOST}/${DB_NAME}`;

const isProd = process.env.NODE_ENV === 'production';

// Harden query parsing & filters
mongoose.set('strictQuery', true);       // reject unknown fields in filters
mongoose.set('sanitizeFilter', true);    // strip $-prefixed operators from filters

// Optional query logging in dev
if (!isProd && process.env.MONGOOSE_DEBUG === 'true') {
  mongoose.set('debug', true);
}

// Connection options (mongoose v7+)
const connectOptions = {
  // NOTE: dbName is ignored if provided in a full URI with its own db
  dbName: DB_NAME,
  maxPoolSize: 10,
  serverSelectionTimeoutMS: 5000,   // fail fast on bad host/creds
  socketTimeoutMS: 45000,           // drop dead sockets
  autoIndex: !isProd,               // speed startup; avoid in prod
  family: 4                         // prefer IPv4 in some corporate/VPN envs
};

// Redact credentials for logs
const redact = (uri) => uri.replace(/\/\/([^@]+)@/, '//***:***@');

// ----- Connect with retry / backoff -----
let shuttingDown = false;

const connectWithRetry = async (attempt = 0) => {
  const delay = Math.min(1000 * Math.pow(2, attempt), 10000); // 1s → 10s
  try {
    await mongoose.connect(DB_URI, connectOptions);
  } catch (err) {
    if (shuttingDown) return;
    console.error(`[db] connect error: ${err.message}`);
    setTimeout(() => connectWithRetry(attempt + 1), delay);
  }
};

// Initial connect
connectWithRetry();

// Auto-reconnect on disconnect (unless we’re shutting down)
mongoose.connection.on('disconnected', () => {
  if (shuttingDown) return;
  console.warn('[db] disconnected – retrying…');
  connectWithRetry(1);
});

mongoose.connection.on('connected', () => {
  console.log(`[db] connected → ${redact(DB_URI)}`);
});

mongoose.connection.on('error', (err) => {
  console.error('[db] connection error:', err.message);
});

// ----- Graceful shutdown -----
const gracefulShutdown = async (reason) => {
  if (shuttingDown) return;
  shuttingDown = true;
  try {
    await mongoose.connection.close();
    console.log(`[db] disconnected (${reason})`);
  } catch (e) {
    console.error('[db] error during shutdown:', e.message);
  }
};

// nodemon restart
process.once('SIGUSR2', async () => {
  await gracefulShutdown('nodemon restart');
  process.kill(process.pid, 'SIGUSR2');
});

// app termination (Ctrl+C)
process.on('SIGINT', async () => {
  await gracefulShutdown('app termination');
  process.exit(0);
});

// container/hosting shutdown
process.on('SIGTERM', async () => {
  await gracefulShutdown('app shutdown');
  process.exit(0);
});

// ----- Load models -----
require('./travlr');

module.exports = mongoose;
