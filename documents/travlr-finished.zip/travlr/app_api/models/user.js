const mongoose = require('mongoose');
const bcrypt = require('bcrypt');
const jwt = require('jsonwebtoken');
const validator = require('validator');

const SALT_ROUNDS   = parseInt(process.env.BCRYPT_ROUNDS || '12', 10);
const JWT_EXPIRES_IN = process.env.JWT_EXPIRES_IN || '1h';

const normalizeEmail = (email) =>
  (validator.normalizeEmail((email || '').trim(), {
    gmail_remove_dots: false,
    gmail_remove_subaddress: true,
    gmail_convert_googlemaildotcom: true
  }) || '').toLowerCase();

const cleanName = (name) =>
  validator.stripLow((name || '').trim(), true).slice(0, 50);

const userSchema = new mongoose.Schema(
  {
    email: {
      type: String,
      unique: true,
      required: [true, 'Email is required'],
      lowercase: true,
      trim: true,
      minlength: [5, 'Email must be at least 5 characters'],
      maxlength: [254, 'Email must be under 254 characters'],
      set: normalizeEmail,
      validate: { validator: validator.isEmail, message: 'Invalid email format' }
    },
    name: {
      type: String,
      required: [true, 'Name is required'],
      trim: true,
      minlength: [2, 'Name must be at least 2 characters'],
      maxlength: [50, 'Name must be under 50 characters'],
      set: cleanName
    },
    passwordHash: {
      type: String,
      required: true,
      select: false
    }
    // roles: { type: [String], default: [] },
  },
  {
    timestamps: true,
    versionKey: false,
    toJSON: {
      transform(_doc, ret) { delete ret.passwordHash; return ret; }
    },
    toObject: {
      transform(_doc, ret) { delete ret.passwordHash; return ret; }
    }
  }
);

// DB-level uniqueness
userSchema.index({ email: 1 }, { unique: true });

/** Set a hashed password */
userSchema.methods.setPassword = async function (plain) {
  if (typeof plain !== 'string' || plain.length < 8) {
    throw new Error('Password must be at least 8 characters');
  }
  this.passwordHash = await bcrypt.hash(plain, SALT_ROUNDS);
};

/** Check a password (document must be loaded with +passwordHash) */
userSchema.methods.validPassword = async function (plain) {
  if (!this.passwordHash) return false;
  return await bcrypt.compare(plain, this.passwordHash);
};

/** Issue a short-lived JWT (issuer/audience optional to match passport.js) */
userSchema.methods.generateJWT = function () {
  if (!process.env.JWT_SECRET) throw new Error('JWT_SECRET is not configured');

  const payload = {
    sub: String(this._id),
    email: this.email,
    name: this.name
  };

  const signOpts = {
    expiresIn: JWT_EXPIRES_IN,
    algorithm: 'HS256',
    ...(process.env.JWT_ISSUER   ? { issuer:  process.env.JWT_ISSUER }   : {}),
    ...(process.env.JWT_AUDIENCE ? { audience: process.env.JWT_AUDIENCE } : {})
  };

  return jwt.sign(payload, process.env.JWT_SECRET, signOpts);
};

/** Safe projection helper */
userSchema.methods.toSafe = function () {
  return { _id: this._id, email: this.email, name: this.name };
};

module.exports = mongoose.model('User', userSchema);
