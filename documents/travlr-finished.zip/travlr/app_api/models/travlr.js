const mongoose = require('mongoose');
const validator = require('validator');

const round2 = (n) => Math.round(n * 100) / 100;

const tripSchema = new mongoose.Schema(
  {
    code: {
      type: String,
      required: true,
      trim: true,
      uppercase: true,
      minlength: 2,
      maxlength: 20,
      match: [/^[A-Z0-9-]+$/, 'Code must be alphanumeric (and dashes)'],
      unique: true,
      immutable: true // we update by code; keep it stable
    },
    name: {
      type: String,
      required: true,
      trim: true,
      minlength: 2,
      maxlength: 80
    },
    length: {
      type: Number,
      required: true,
      min: 1,
      max: 365
    },
    start: {
      type: Date,
      required: true
    },
    resort: {
      type: String,
      required: true,
      trim: true,
      minlength: 2,
      maxlength: 80
    },
    perPerson: {
      type: Number,
      required: true,
      min: 0,
      max: 1_000_000,
      set: round2 // store to 2 decimals
    },
    image: {
      type: String,
      trim: true,
      default: '',
      validate: {
        validator: (v) =>
          v === '' ||
          validator.isURL(v, {
            protocols: ['http', 'https'],
            require_protocol: true
          }),
        message: 'Image must be an http(s) URL'
      }
    },
    description: {
      type: String,
      required: true,
      trim: true,
      minlength: 10,
      maxlength: 2000
    }
  },
  {
    timestamps: true,
    versionKey: false,
    toJSON: {
      transform(_doc, ret) {
        return ret;
      }
    },
    toObject: {
      transform(_doc, ret) {
        return ret;
      }
    }
  }
);

// Indexes
tripSchema.index({ code: 1 }, { unique: true });
tripSchema.index(
  { name: 'text', resort: 'text', description: 'text' },
  { weights: { name: 4, resort: 2, description: 1 } }
);

module.exports = mongoose.model('Trip', tripSchema);
