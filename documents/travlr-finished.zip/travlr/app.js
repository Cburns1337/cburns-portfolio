// Core
const express = require('express');
const app = express();
const path = require('path');
const cookieParser = require('cookie-parser');
const morgan = require('morgan');
const createError = require('http-errors');

// Security & perf
const cors = require('cors');
const helmet = require('helmet');
const rateLimit = require('express-rate-limit');
const mongoSanitize = require('express-mongo-sanitize');
const compression = require('compression');

// Views
const hbs = require('hbs');

// Env
require('dotenv').config();

// Passport (JWT/local)
const passport = require('passport');
require('./app_api/config/passport');

// DB (connect early)
require('./app_api/models/db');

// ---------- App hardening ----------
app.disable('x-powered-by');
if (process.env.NODE_ENV === 'production') {
  // if behind a proxy/load balancer (Heroku/Render/Nginx), enable correct IPs for rate-limits
  app.set('trust proxy', 1);
}

// Helmet (with permissive CORP so static/media work across origins if needed)
app.use(
  helmet({
    crossOriginResourcePolicy: { policy: 'cross-origin' },
  })
);

// Compression
app.use(compression());

// Logging
app.use(morgan(process.env.NODE_ENV === 'production' ? 'combined' : 'dev'));

// Body parsing & cookies
app.use(express.json({ limit: '1mb' }));
app.use(express.urlencoded({ extended: false }));
app.use(cookieParser());

// Mongo query sanitization
app.use(mongoSanitize());

// ---------- CORS ----------
const allowedOrigins = (process.env.CORS_ORIGINS || 'http://localhost:4200')
  .split(',')
  .map((s) => s.trim())
  .filter(Boolean);

app.use(
  cors({
    origin: (origin, cb) => {
      if (!origin) return cb(null, true); // allow curl/postman
      return allowedOrigins.includes(origin)
        ? cb(null, true)
        : cb(new Error('Not allowed by CORS'));
    },
    credentials: true,
    methods: ['GET', 'POST', 'PUT', 'DELETE', 'OPTIONS'],
    allowedHeaders: [
      'Origin',
      'X-Requested-With',
      'Content-Type',
      'Accept',
      'Authorization',
    ],
  })
);

// Let CORS handle preflights
app.options('*', cors());

// ---------- View engine ----------
app.set('views', path.join(__dirname, 'app_server', 'views'));
hbs.registerPartials(path.join(__dirname, 'app_server', 'views', 'partials'));
app.set('view engine', 'hbs');

// Static assets
app.use(express.static(path.join(__dirname, 'public')));

// ---------- Auth & rate limits ----------
app.use(passport.initialize());

// Conservative API-wide limiter; stricter on auth endpoints
const apiLimiter = rateLimit({
  windowMs: 15 * 60 * 1000,
  max: parseInt(process.env.RATE_LIMIT_MAX || '200', 10), // per IP per 15m
});
const authLimiter = rateLimit({
  windowMs: 15 * 60 * 1000,
  max: parseInt(process.env.RATE_LIMIT_AUTH_MAX || '20', 10),
});

app.use('/api/login', authLimiter);
app.use('/api/register', authLimiter);

// ---------- Routers ----------
const indexRouter = require('./app_server/routes/index');
const usersRouter = require('./app_server/routes/users');
const travelRouter = require('./app_server/routes/travel');
const apiRouter = require('./app_api/routes/index');

app.use('/', indexRouter);
app.use('/users', usersRouter);
app.use('/travel', travelRouter);

// Mount API (after limiters)
app.use('/api', apiLimiter, apiRouter);

// Health endpoint (for uptime checks)
app.get('/healthz', (_req, res) => res.status(200).json({ ok: true }));

// ---------- 404 ----------
app.use((req, res, next) => {
  if (req.path.startsWith('/api')) {
    return res.status(404).json({ message: 'Not found' });
  }
  return next(createError(404));
});

// ---------- Error handling ----------
app.use((err, req, res, _next) => {
  // JWT/Passport errors bubble up as 401
  if (err.name === 'UnauthorizedError') {
    return res.status(401).json({ message: `${err.name}: ${err.message}` });
  }

  const status = err.status || 500;

  if (req.path.startsWith('/api')) {
    // API returns JSON (no stack in prod)
    const payload = { message: err.message || 'Server error' };
    if (process.env.NODE_ENV !== 'production' && err.stack) {
      payload.stack = err.stack;
    }
    return res.status(status).json(payload);
  }

  // Server-rendered pages use error view
  res.locals.message = err.message;
  res.locals.error =
    req.app.get('env') === 'development' ? err : {};
  res.status(status);
  res.render('error');
});

module.exports = app;
